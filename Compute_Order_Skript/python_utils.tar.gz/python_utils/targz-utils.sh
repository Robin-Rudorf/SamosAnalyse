#!/bin/bash
cd ..
tar cfvz python_utils.tar.gz python_utils
